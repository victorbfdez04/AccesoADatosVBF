package com.break4learning.clasefile.controlador;

import com.break4learning.clasefile.modelo.Archivo;
import com.break4learning.clasefile.modelo.Carpeta;
import com.break4learning.clasefile.vista.InterfazVista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlCarpeta implements ActionListener {

    private final InterfazVista vista;
    private final Carpeta modelo;
    private final Archivo archivo;

    public ControlCarpeta(InterfazVista vista, Carpeta modelo) {
        this.vista = vista;
        this.modelo = modelo;
        this.archivo = new Archivo();

        this.vista.setControlador(this);
        this.vista.arranca();
    }

    @Override
    public void actionPerformed(ActionEvent evento) {

        String ruta = vista.getRuta();
        modelo.setRuta(ruta);

        switch (evento.getActionCommand()) {

            case InterfazVista.CREARCARPETACONRUTACOMPLETA -> {
                modelo.crearCarpeta();
            }

            case InterfazVista.CREARCARPETACONRUTAPADREYNOMBRE -> {
                String nombre = vista.getNombre();
                modelo.crearCarpeta(nombre);
            }

            case InterfazVista.CREARCARPETACONFILERUTAPADREYNOMBRE -> {
                String nombre = vista.getNombre();
                modelo.crearCarpeta(modelo.getFileDeRuta(), nombre);
            }

            case InterfazVista.CREARARCHIVO -> {
                String nombreArchivo = vista.getNombreArchivo();
                archivo.crearArchivo(ruta, nombreArchivo);
            }

            default -> {
            }
        }

        vista.arranca();
    }
}