/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.break4learning.clasefile.modelo;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author b15-01m
 */
public class Archivo {
    
    /**
     *
     * @param rutaCarpeta
     * @param nombreArchivo
     * @return
     */
    public File crearArchivo(String rutaCarpeta, String nombreArchivo){
        File archivo = new File(rutaCarpeta, nombreArchivo);
        try{
            archivo.createNewFile();
            return archivo;
        } catch (IOException e){
            return archivo;
        }
    }    
    
    public File crearArchivo(File carpeta, String nombreArchivo){
        File archivo = new File(carpeta, nombreArchivo);
        try{
            archivo.createNewFile();
            return archivo;
        } catch (IOException e){
            return archivo;
        }
    } 
}
