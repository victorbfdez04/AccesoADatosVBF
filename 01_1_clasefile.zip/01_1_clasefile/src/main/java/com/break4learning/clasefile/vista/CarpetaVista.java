package com.break4learning.clasefile.vista;

import com.break4learning.clasefile.controlador.ControlCarpeta;
import java.io.File;
import java.awt.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CarpetaVista implements InterfazVista {

    private ControlCarpeta controlador;

    @FXML
    private TextField txtRuta;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtNombreArchivo;

    @FXML
    private ListView<String> listaContenido;

    @Override
    public void setControlador(ControlCarpeta c) {
        this.controlador = c;
    }

    @Override
    public void arranca() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("carpeta-view.fxml")
            );

            loader.setController(this);

            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Gestión de carpetas y archivos");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getRuta() {
        return txtRuta.getText();
    }

    @Override
    public String getNombre() {
        return txtNombre.getText();
    }

    @Override
    public String getNombreArchivo() {
        return txtNombreArchivo.getText();
    }

    @Override
    public void mostrarContenido(File[] contenido) {
        listaContenido.getItems().clear();

        for (File elemento : contenido) {
            if (elemento.isDirectory()) {
                listaContenido.getItems().add(
                        "Directorio: " + elemento.getName()
                );
            } else if (elemento.isFile()) {
                listaContenido.getItems().add(
                        "Archivo: " + elemento.getName()
                        + " | Tamaño: " + elemento.length() + " bytes"
                );
            }
        }
    }

    @FXML
    private void crearCarpetaRutaCompleta() {
        controlador.actionPerformed(
                new ActionEvent(
                        this,
                        1,
                        InterfazVista.CREARCARPETACONRUTACOMPLETA
                )
        );
    }

    @FXML
    private void crearCarpetaRutaNombre() {
        controlador.actionPerformed(
                new ActionEvent(
                        this,
                        2,
                        InterfazVista.CREARCARPETACONRUTAPADREYNOMBRE
                )
        );
    }

    @FXML
    private void crearCarpetaFile() {
        controlador.actionPerformed(
                new ActionEvent(
                        this,
                        3,
                        InterfazVista.CREARCARPETACONFILERUTAPADREYNOMBRE
                )
        );
    }

    @FXML
    private void crearArchivo() {
        controlador.actionPerformed(
                new ActionEvent(
                        this,
                        4,
                        InterfazVista.CREARARCHIVO
                )
        );
    }
}