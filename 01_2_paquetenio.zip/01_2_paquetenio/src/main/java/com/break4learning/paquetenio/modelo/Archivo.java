package com.break4learning.paquetenio.modelo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Clase encargada de las operaciones con archivos.
 */
public class Archivo {

    /**
     * Crea un archivo indicando la ruta de la carpeta
     * y el nombre del archivo.
     *
     * @param rutaCarpeta Ruta de la carpeta
     * @param nombreArchivo Nombre del archivo
     * @return Path del archivo creado
     * @throws IOException Si se produce un error al crear el archivo
     */
    public Path crearArchivo(String rutaCarpeta, String nombreArchivo) throws IOException {

        Path carpeta = Paths.get(rutaCarpeta);
        Path archivo = carpeta.resolve(nombreArchivo);

        Files.createFile(archivo);

        return archivo;
    }

    /**
     * Crea un archivo indicando la carpeta como Path
     * y el nombre del archivo.
     *
     * @param carpeta Carpeta donde se creará el archivo
     * @param nombreArchivo Nombre del archivo
     * @return Path del archivo creado
     * @throws IOException Si se produce un error al crear el archivo
     */
    public Path crearArchivo(Path carpeta, String nombreArchivo) throws IOException {

        Path archivo = carpeta.resolve(nombreArchivo);

        Files.createFile(archivo);

        return archivo;
    }
}