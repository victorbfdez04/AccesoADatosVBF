package com.break4learning.paquetenio.vista;

import com.break4learning.paquetenio.controlador.ControlCarpeta;
import java.awt.event.ActionEvent;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CarpetaVistaGrafica implements InterfazVista {

    private ControlCarpeta controlador;
    private Stage stage;

    @FXML private TextField txtRuta;
    @FXML private TextField txtNombre;
    @FXML private TextField txtNombreArchivo;

    @Override
    public void setControlador(ControlCarpeta c) {
        this.controlador = c;
    }

    @Override
    public void arranca() {
        if (stage != null) {
            return;   // ya está abierta
        }
        try {
            // Inicia el toolkit de JavaFX y ejecuta mostrarVentana() en su hilo
            Platform.startup(this::mostrarVentana);
        } catch (IllegalStateException e) {
            // JavaFX ya estaba iniciado
            Platform.runLater(this::mostrarVentana);
        }
    }

    private void mostrarVentana() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/CarpetaVistaGrafica.fxml"));
            loader.setControllerFactory(clase -> this);   // usa ESTA instancia como controlador
            Parent root = loader.load();

            stage = new Stage();
            stage.setTitle("Gestión de archivos y carpetas");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            Platform.exit();   // si falla la carga, que el programa no se quede colgado sin ventana
        }
    }

    @FXML
    private void onCrearCarpetaRutaCompleta() {
        controlador.actionPerformed(new ActionEvent(this, 1, CREARCARPETACONRUTACOMPLETA));
    }

    @FXML
    private void onCrearCarpetaPadreNombre() {
        controlador.actionPerformed(new ActionEvent(this, 2, CREARCARPETACONRUTAPADREYNOMBRE));
    }

    @FXML
    private void onCrearCarpetaFilePadreNombre() {
        controlador.actionPerformed(new ActionEvent(this, 3, CREARCARPETACONFILERUTAPADREYNOMBRE));
    }

    @FXML
    private void onCrearArchivo() {
        controlador.actionPerformed(new ActionEvent(this, 4, CREARARCHIVO));
    }

    @Override public String getRuta()          { 
        return txtRuta.getText(); 
    }
    @Override public String getNombre()        { 
        return txtNombre.getText(); 
    }
    @Override public String getNombreArchivo() { 
        return txtNombreArchivo.getText(); 
    }
}