package com.break4learning.paquetenio.vista;

import com.break4learning.paquetenio.controlador.ControlCarpeta;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CarpetaVistaGrafica implements InterfazVista {

    private ControlCarpeta controlador;
    private Stage stage;
    @FXML
    private TextField txtRuta;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtNombreArchivo;
    
    @Override
    public void setControlador(ControlCarpeta c) {
        this.controlador = c;
    }
    
    @Override
    public void arranca() {
        if (stage != null && stage.isShowing()) {
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/CarpetaVistaGrafica.fxml")
            );

            Parent root = loader.load();

            Scene scene = new Scene(root, 500, 400);

            stage = new Stage();
            stage.setTitle("Gestión de archivos y carpetas");
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getRuta() {
        return txtRuta.getText();
    }

    @Override
    public String getNombre() {
        return txtNombre.getText();
    }

    @Override
    public String getNombreArchivo() {
        return txtNombreArchivo.getText();
    }
}