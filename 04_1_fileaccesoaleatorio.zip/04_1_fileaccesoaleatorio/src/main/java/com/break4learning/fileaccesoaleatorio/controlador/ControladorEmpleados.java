package com.break4learning.fileaccesoaleatorio.controlador;

import com.break4learning.fileaccesoaleatorio.modelo.Empleado;
import com.break4learning.fileaccesoaleatorio.modelo.LecturaEscritura;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ControladorEmpleados {

    @FXML
    private TextField txtIdentificador;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtDepartamento;

    @FXML
    private TextField txtSalario;

    @FXML
    private TableView<Empleado> tablaEmpleados;

    @FXML
    private TableColumn<Empleado, Long> colIdentificador;

    @FXML
    private TableColumn<Empleado, String> colApellido;

    @FXML
    private TableColumn<Empleado, Integer> colDepartamento;

    @FXML
    private TableColumn<Empleado, Double> colSalario;

    private final LecturaEscritura lecturaEscritura =
            new LecturaEscritura("empleados.dat");

    @FXML
    private void initialize() {

        colIdentificador.setCellValueFactory(
                new PropertyValueFactory<>("identificador"));

        colApellido.setCellValueFactory(
                new PropertyValueFactory<>("apellido"));

        colDepartamento.setCellValueFactory(
                new PropertyValueFactory<>("departamento"));

        colSalario.setCellValueFactory(
                new PropertyValueFactory<>("salario"));

        txtIdentificador.setEditable(false);

        cargarEmpleados();
    }

    @FXML
    private void guardarEmpleado() {

        try {
            String apellido = txtApellido.getText().trim();
            int departamento = Integer.parseInt(txtDepartamento.getText().trim());
            double salario = Double.parseDouble(
                    txtSalario.getText().trim().replace(',', '.'));

            if (apellido.isEmpty()) {
                mostrarError("El apellido no puede estar vacío.");
                return;
            }

            if (apellido.length() > 10) {
                mostrarError("El apellido no puede tener más de 10 caracteres.");
                return;
            }

            Empleado empleado = new Empleado(
                    apellido,
                    departamento,
                    salario
            );

            lecturaEscritura.escribirEmpleadoFinalArchivo(empleado);

            cargarEmpleados();
            limpiarCampos();

        } catch (NumberFormatException ex) {
            mostrarError("Departamento debe ser un entero y salario un número.");
        }
    }

    private void cargarEmpleados() {

        try {
            ObservableList<Empleado> datos =
                    FXCollections.observableArrayList(
                            lecturaEscritura.listarEmpleados());

            tablaEmpleados.setItems(datos);

            if (!datos.isEmpty()) {
                txtIdentificador.setText(
                        String.valueOf(datos.get(datos.size() - 1).getIdentificador()));
            }

        } catch (IOException ex) {
            mostrarError("No se ha podido leer el fichero de empleados.");
        }
    }

    private void limpiarCampos() {
        txtApellido.clear();
        txtDepartamento.clear();
        txtSalario.clear();
    }

    private void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}
