package com.break4learning.fileaccesoaleatorio.modelo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LecturaEscritura extends FicheroEmpleados {

    public LecturaEscritura(String ruta) {
        super(ruta);
    }

    /**
     * Devuelve un empleado con el identificador dado.
     *
     * @param identificador Id del empleado que queremos mostrar
     * @return Empleado con sus datos
     */
    public Empleado lecturaEmpleado(int identificador) {

        long posicion;
        Empleado empleado = new Empleado();

        try (RandomAccessFile randomFile = new RandomAccessFile(getRuta(), "r")) {

            posicion = (long) (identificador - 1) * super.getLONGITUD_TOTAL();

            if (identificador > 0 && posicion < randomFile.length()) {
                randomFile.seek(posicion);

                empleado.setIdentificador(randomFile.readLong());
                empleado.setApellido(leerApellido(randomFile));
                empleado.setDepartamento(randomFile.readInt());
                empleado.setSalario(randomFile.readDouble());
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(LecturaEscritura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LecturaEscritura.class.getName()).log(Level.SEVERE, null, ex);
        }

        return empleado;
    }

    /**
     * Lee todos los empleados almacenados en el fichero.
     *
     * @return lista de empleados
     */
    public List<Empleado> listarEmpleados() throws IOException {

        List<Empleado> empleados = new ArrayList<>();

        if (!getRuta().exists()) {
            return empleados;
        }

        try (RandomAccessFile randomFile = new RandomAccessFile(getRuta(), "r")) {

            while (randomFile.getFilePointer() < randomFile.length()) {
                Empleado empleado = new Empleado();

                empleado.setIdentificador(randomFile.readLong());
                empleado.setApellido(leerApellido(randomFile));
                empleado.setDepartamento(randomFile.readInt());
                empleado.setSalario(randomFile.readDouble());

                empleados.add(empleado);
            }
        }

        return empleados;
    }

    /**
     * Lee el apellido almacenado como 10 caracteres Java.
     */
    private String leerApellido(RandomAccessFile randomFile) throws IOException {

        StringBuilder apellido = new StringBuilder();

        for (int i = 0; i < super.getCARACTERES_APELLIDO(); i++) {
            apellido.append(randomFile.readChar());
        }

        return apellido.toString().replace("\0", "").trim();
    }

    /**
     * Añade un empleado al final del archivo.
     *
     * @param empleado Empleado con los datos a añadir
     */
    public void escribirEmpleadoFinalArchivo(Empleado empleado) {

        long posicion = 0;

        try (RandomAccessFile randomFile = new RandomAccessFile(getRuta(), "rw")) {

            if (randomFile.length() != 0) {
                posicion = randomFile.length();
            }

            randomFile.seek(posicion);

            // El identificador se genera automáticamente.
            randomFile.writeLong(posicion / super.getLONGITUD_TOTAL() + 1);

            String apellido = empleado.getApellido();

            if (apellido == null) {
                apellido = "";
            }

            if (apellido.length() > super.getCARACTERES_APELLIDO()) {
                apellido = apellido.substring(0, super.getCARACTERES_APELLIDO());
            }

            StringBuffer bufferStr = new StringBuffer(apellido);
            bufferStr.setLength(super.getCARACTERES_APELLIDO());
            randomFile.writeChars(bufferStr.toString());

            randomFile.writeInt(empleado.getDepartamento());
            randomFile.writeDouble(empleado.getSalario());

        } catch (FileNotFoundException ex) {
            Logger.getLogger(LecturaEscritura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LecturaEscritura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
