/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.streamcaracteres2026;

import com.mycompany.streamcaracteres2026.modelo.LecturaEscritura;
import com.mycompany.streamcaracteres2026.controlador.ControlLecturaEscritura;
import com.mycompany.streamcaracteres2026.vista.Vista;

/**
 *
 * @author b15-01m
 */
public class Streamcaracteres2026 {

 /*   public static void main(String[] args) {
        LecturaEscritura fichero = new LecturaEscritura("./prueba/fichero.txt");
        fichero.escribirStreamBufferedPrintCaracteres("Primera linea", false);
        fichero.escribirStreamBufferedPrintCaracteres("Segunda linea", true);
        fichero.escribirStreamBufferedPrintCaracteres("Tercera linea", true);
        
        System.out.println(fichero.leerCaracteresBufferReader());
    }*/
    public static void main(String[] args) {
        LecturaEscritura modelo = new LecturaEscritura("./prueba/fichero.txt");
        Vista vista = new Vista();
        new ControlLecturaEscritura(modelo, vista).iniciar();
    }
    
}
