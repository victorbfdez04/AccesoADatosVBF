package com.mycompany.streamcaracteres2026.controlador;

import com.mycompany.streamcaracteres2026.modelo.LecturaEscritura;
import com.mycompany.streamcaracteres2026.vista.Vista;

public class ControlLecturaEscritura {

    private final LecturaEscritura modelo;
    private final Vista vista;

    public ControlLecturaEscritura(LecturaEscritura modelo, Vista vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu(modelo.getRutayNombreArchivo());
            opcion = vista.pedirEntero("Opción: ");

            switch (opcion) {
                case 1 -> vista.mostrarContenido("Carácter a carácter", modelo.leerCaracteresFileReader());
                case 2 -> vista.mostrarContenido("Por cadenas", modelo.leerCadenasFileReader());
                case 3 -> vista.mostrarContenido("Línea a línea", modelo.leerCaracteresBufferReader());
                case 4 -> modelo.escribirStreamCaracteres(vista.pedirTexto("Texto: "),
                        vista.pedirSiNo("¿Añadir al final? (s/n): "));
                case 5 -> modelo.escribirStreamCadena(vista.pedirTexto("Texto: "),
                        vista.pedirSiNo("¿Añadir al final? (s/n): "));
                case 6 -> modelo.escribirStreamBufferedPrintCaracteres(vista.pedirTexto("Línea: "),
                        vista.pedirSiNo("¿Añadir al final? (s/n): "));
                case 7 -> {
                    int clave = vista.pedirEntero("Clave (desplazamiento): ");
                    vista.mostrarMensaje("Copia encriptada: " + modelo.encriptar(clave));
                }
                case 8 -> {
                    int clave = vista.pedirEntero("Clave (la misma que al encriptar): ");
                    vista.mostrarMensaje("Copia desencriptada: " + modelo.desencriptar(clave));
                }
                case 9 -> modelo.setRutayNombreArchivo(vista.pedirTexto("Nueva ruta del fichero: "));
                case 0 -> vista.mostrarMensaje("Hasta pronto.");
                default -> vista.mostrarMensaje("Opción no válida.");
            }
        } while (opcion != 0);
    }
}