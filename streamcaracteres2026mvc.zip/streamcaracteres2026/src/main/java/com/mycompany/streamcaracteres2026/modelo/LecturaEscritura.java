/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.streamcaracteres2026.modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author b15-01m
 */
public class LecturaEscritura {
    
    private File rutayNombreArchivo;

    public LecturaEscritura() {
    }
    
    public LecturaEscritura(String rutayNombreArchivo) {
        this.rutayNombreArchivo = new File(rutayNombreArchivo);
    }

    public String getRutayNombreArchivo() {
        return rutayNombreArchivo.getAbsolutePath();
    }

    public void setRutayNombreArchivo(String rutayNombreArchivo) {
        this.rutayNombreArchivo = new File(rutayNombreArchivo);
    }
    
    public void escribirStreamBufferedPrintCaracteres(String cadena, boolean sobreescribe){
        
        try {
            FileWriter ficheroOut = null;
            ficheroOut = new FileWriter(getRutayNombreArchivo(),sobreescribe);
            
            PrintWriter bufferficheroOut = new PrintWriter(ficheroOut);
            bufferficheroOut.println(cadena);
            
            bufferficheroOut.flush();
            bufferficheroOut.close();
        } catch (IOException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        
    }
    
    public String leerCaracteresBufferReader(){
        
        StringBuilder texto = new StringBuilder();
        FileReader ficheroIn = null;

        try {
            String linea;
            
            ficheroIn = new FileReader(getRutayNombreArchivo());
            BufferedReader bufferficheroIn = new BufferedReader(ficheroIn);
            linea = bufferficheroIn.readLine();
            
            while(linea != null){
                texto.append(linea).append(System.lineSeparator());
                linea = bufferficheroIn.readLine();
            }
        } catch (FileNotFoundException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } catch (IOException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } finally {
            try {
                ficheroIn.close();
            } catch (IOException ex) {
                System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }
        
        return texto.toString();
    }
    
    public String leerCaracteresFileReader(){

        StringBuilder texto = new StringBuilder();
        FileReader ficheroIn = null;

        try {
            int caracter;

            ficheroIn = new FileReader(getRutayNombreArchivo());
            caracter = ficheroIn.read();

            while (caracter != -1) {
                texto.append((char) caracter);
                caracter = ficheroIn.read();
            }
        } catch (FileNotFoundException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } catch (IOException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } finally {
            try {
                if (ficheroIn != null) {
                    ficheroIn.close();
                }
            } catch (IOException ex) {
                System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }

        return texto.toString();
    }
    
    public String leerCadenasFileReader(){

        StringBuilder texto = new StringBuilder();
        FileReader ficheroIn = null;

        try {
            char[] buffer = new char[16];
            int leidos;

            ficheroIn = new FileReader(getRutayNombreArchivo());
            leidos = ficheroIn.read(buffer);

            while (leidos != -1) {
                texto.append(new String(buffer, 0, leidos));
                leidos = ficheroIn.read(buffer);
            }
        } catch (FileNotFoundException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } catch (IOException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } finally {
            try {
                if (ficheroIn != null) {
                    ficheroIn.close();
                }
            } catch (IOException ex) {
                System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }

        return texto.toString();
    }
    
    
    
    public void escribirStreamCaracteres(String cadena, boolean sobreescribe){

        FileWriter ficheroOut = null;

        try {
            ficheroOut = new FileWriter(getRutayNombreArchivo(), sobreescribe);

            for (int i = 0; i < cadena.length(); i++) {
                ficheroOut.write(cadena.charAt(i)); //no hay salto de linea ni espacios
            }
            ficheroOut.flush();
        } catch (IOException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } finally {
            try {
                if (ficheroOut != null) {
                    ficheroOut.close();
                }
            } catch (IOException ex) {
                System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }
    }
    
    public void escribirStreamCadena(String cadena, boolean sobreescribe){

        FileWriter ficheroOut = null;

        try {
            ficheroOut = new FileWriter(getRutayNombreArchivo(), sobreescribe);
            ficheroOut.write(cadena);
            ficheroOut.flush();
        } catch (IOException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } finally {
            try {
                if (ficheroOut != null) {
                    ficheroOut.close();
                }
            } catch (IOException ex) {
                System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }
    }
    
    private char desplazar(char c, int desplazamiento){
            if (c >= 'a' && c <= 'z') {
                return (char) ('a' + Math.floorMod(c - 'a' + desplazamiento, 26));
            }
            if (c >= 'A' && c <= 'Z') {
                return (char) ('A' + Math.floorMod(c - 'A' + desplazamiento, 26));
            }
            return c;
        }

        public String encriptar(int clave){
        return transformar(clave, "encriptado_");
    }

    public String desencriptar(int clave){
        return transformar(-clave, "desencriptado_");
    }

    private String transformar(int desplazamiento, String prefijo){

        File destino = new File(rutayNombreArchivo.getAbsoluteFile().getParentFile(),
                prefijo + rutayNombreArchivo.getName());
        FileReader ficheroIn = null;
        FileWriter ficheroOut = null;

        try {
            int caracter;

            ficheroIn = new FileReader(getRutayNombreArchivo());
            ficheroOut = new FileWriter(destino);
            caracter = ficheroIn.read();

            while (caracter != -1) {
                ficheroOut.write(desplazar((char) caracter, desplazamiento));
                caracter = ficheroIn.read();
            }
            ficheroOut.flush();
        } catch (FileNotFoundException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } catch (IOException ex) {
            System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        } finally {
            try {
                if (ficheroIn != null) {
                    ficheroIn.close();
                }
            } catch (IOException ex) {
                System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            try {
                if (ficheroOut != null) {
                    ficheroOut.close();
                }
            } catch (IOException ex) {
                System.getLogger(LecturaEscritura.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }

        return destino.getAbsolutePath();
    }
}
