package com.mycompany.streamcaracteres2026.vista;

import java.util.Scanner;

public class Vista {

    private final Scanner teclado = new Scanner(System.in);

    public void mostrarMenu(String rutaActual) {
        System.out.println();
        System.out.println("=== FileStreamsCaracteres ===");
        System.out.println("Fichero de trabajo: " + rutaActual);
        System.out.println(" 1. Leer carácter a carácter");
        System.out.println(" 2. Leer por cadenas");
        System.out.println(" 3. Leer línea a línea");
        System.out.println(" 4. Escribir carácter a carácter");
        System.out.println(" 5. Escribir una cadena (String)");
        System.out.println(" 6. Escribir una línea");
        System.out.println(" 7. Generar copia encriptada");
        System.out.println(" 8. Generar copia desencriptada");
        System.out.println(" 9. Cambiar fichero de trabajo");
        System.out.println(" 0. Salir");
    }

    public String pedirTexto(String mensaje) {
        System.out.print(mensaje);
        return teclado.nextLine();
    }

    public int pedirEntero(String mensaje) {
        while (true) {
            try {
                return Integer.parseInt(pedirTexto(mensaje).trim());
            } catch (NumberFormatException ex) {
                mostrarMensaje("Introduce un número entero.");
            }
        }
    }

    public boolean pedirSiNo(String mensaje) {
        return pedirTexto(mensaje).trim().equalsIgnoreCase("s");
    }

    public void mostrarContenido(String titulo, String contenido) {
        System.out.println("----- " + titulo + " -----");
        System.out.print(contenido);
        System.out.println("----- fin -----");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}